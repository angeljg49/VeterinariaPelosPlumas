<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\propietario;
use App\Models\usuario;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;

class propietarioController extends Controller
{
    private $modulo = "propietarios";

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $propietarios = propietario::all();      

        return view('propietarios.lista_propietarios', ['titulo'=>'Gestionar propietarios',
                                                          'propietarios' => $propietarios,
                                                          'modulo_activo' => $this->modulo
                                                         ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $titulo = 'NUEVo propietario';
        $propietarios = propietario::all();

        return view('propietarios.form_nueva_propietario', ['titulo'=>$titulo, 
                                                   'propietarios' => $propietarios,
                                                   'modulo_activo' => $this->modulo
                                                 ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $usuario = new Usuario();
        $usuario->usu_nombre = $request->input('usu_nombre');
        $usuario->password = Hash::make($request->input('usu_password'));
        $usuario->usu_email = $request->input('usu_email');
        $usuario->usu_rol = 2;
        $usuario->save();


        $propietario = new propietario();
        $propietario->usu_id = $usuario->usu_id;
        $propietario->pro_nombre_completo = $request->input('pro_nombre_completo');
        $propietario->pro_ci = $request->input('pro_ci');
        $propietario->pro_direccion = $request->input('pro_direccion');
        $propietario->pro_zona = $request->input('pro_zona');
        $propietario->save();

        return redirect('propietarios');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $id = Crypt::decryptString($id);//Desencriptando parametro ID
        $titulo = 'EDITAR propietario';
        $propietario = propietario::where('pro_id', $id)->first();

        return view('propietarios.form_editar_propietario', ['titulo'=>$titulo, 
                                                   'propietario' => $propietario,
                                                   'modulo_activo' => $this->modulo
                                                 ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $propietario = propietario::where('pro_id', $id)->first();

        $usuario = usuario::where('usu_id', $propietario->usuario->usu_id)->first();
        $usuario->usu_nombre = $request->input('usu_nombre');
        // $usuario->password = Hash::make($request->input('usu_password'));
        $usuario->usu_email = $request->input('usu_email');
        // $usuario->usu_rol = 2;
        $usuario->save();

        
        // $propietario->usu_id = $usuario->usu_id;
        $propietario->pro_nombre_completo = $request->input('pro_nombre_completo');
        $propietario->pro_ci = $request->input('pro_ci');
        $propietario->pro_direccion = $request->input('pro_direccion');
        $propietario->pro_zona = $request->input('pro_zona');
        $propietario->save();
        return redirect('propietarios');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $propietario = propietario::where('pro_id', $id)->first();
        $propietario->delete();
        return redirect('propietarios');
    }
}
