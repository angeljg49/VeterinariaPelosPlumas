<!DOCTYPE html>
<html>
<head>
    <title>Casa Propia</title>
</head>
<body>
    <h1>{{ $detalles['title'] }}</h1>
    <p>{{ $detalles['body'] }}</p>
    {{-- <h1>HOLA MUNDO</h1>
    <p>Desde casa propia</p> --}}
   
    <p>Thank you</p>
</body>
</html>